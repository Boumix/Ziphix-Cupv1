// vote kick//

minVoteAmt = 5 -- Amount of 'yes' votes needed to kick the player.

voteWaitTime = 10 -- Time in MINUTES that players must wait before using the voteCmd again (to prevent vote-to-kick spam).

playerKickMessages = true -- Do you want a kick message to display in chat when a player is kicked?

kickMessage = "You were vote kicked from the server" -- Message displayed to the player when they are vote kicked.

voteCmd = "votekick" -- Command that starts the vote to kick process.

CancelCmd = "cancelvote" -- Command to cancel the vote-to-kick event (Admin Use Only).

voteYesCmd = "voteyes" -- Command to vote yes on the kick.

voteNoCmd = "voteno" -- Command to vote no on the kick.

faxDebug = false -- Only set to true if asked by FAXES.
