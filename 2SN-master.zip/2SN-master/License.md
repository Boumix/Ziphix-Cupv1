## Terms of Use

(Below the term "product" is used to describe the script / modification)

This script is freeware and is not to be exploited for personal, financial or commercial gain. This product is provided without any form of warranty.
Therefore, responsibility for any damages caused by this product or its misuse rest solely with the user, as the author(s) will accept no liability.

- This copy of terms must remain in its original state and must not be modified in anyway

- These terms must be alongside the product at all times

- Do not re-release with out permission (just ask for permission)

- Do not redistribute to any other sites. This script is only to be published on verified sites by FAXES

- Editing / abusing these terms will result in action

### Summery
So basically you can edit anything with the product (except the terms), but you can not release the product nor release the edited version without written permission from FAXES. 

Terms are also available at 
[www.faxes.zone/scripts/terms](http://faxes.zone/scripts/terms)


![alt text](http://faxes.zone/files/logos/FAXES%20ToUSML.png "FAXES ToU Icon")
