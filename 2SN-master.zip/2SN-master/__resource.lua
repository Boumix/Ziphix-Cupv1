-----------------------------------
--- Vote to Kick, Made by FAXES ---
-----------------------------------

client_script "client.lua"

server_script "config.lua"
server_script "server.lua"